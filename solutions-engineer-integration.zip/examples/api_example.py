# Example API call demonstrating technical literacy
# This example focuses on clarity rather than performance or completeness

import requests

API_ENDPOINT = "https://api.example.com/v1/resource"
API_KEY = "YOUR_API_KEY"

def fetch_resource(resource_id):
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    response = requests.get(f"{API_ENDPOINT}/{resource_id}", headers=headers, timeout=5)

    if response.status_code == 200:
        return response.json()
    else:
        # Explicit error handling to avoid silent failures
        raise Exception(f"API error: {response.status_code} - {response.text}")

if __name__ == "__main__":
    try:
        data = fetch_resource("example-id")
        print("Resource fetched successfully:", data)
    except Exception as e:
        print("Error:", e)
